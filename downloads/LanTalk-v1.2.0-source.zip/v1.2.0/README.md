# 💬 LanTalk - 内网聊天室系统

![Version](https://img.shields.io/badge/version-1.2.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Node.js](https://img.shields.io/badge/node.js-16%2B-brightgreen.svg)

一个功能丰富的内网实时聊天室系统，支持多房间聊天、Markdown消息、权限管理和专业的管理面板。

## ✨ 特性功能

### 🏠 多房间聊天
- **房间创建**: 用户可以创建主题聊天室
- **房间切换**: 实时切换不同房间，独立消息历史
- **房间管理**: 管理员可以删除房间和踢出用户
- **强制操作**: 支持强制删除有用户的房间

### 📝 富文本消息
- **Markdown支持**: 完整的Markdown语法渲染
- **实时预览**: 消息发送前自动格式化
- **代码高亮**: 支持代码块和语法高亮
- **安全渲染**: 所有HTML内容经过安全消毒

### 👮 权限管理
- **IP禁言**: 基于IP地址的用户禁言系统
- **权限控制**: 被禁言用户无法发送消息和创建房间
- **管理员特权**: 管理面板拥有完整系统控制权
- **实时同步**: 权限状态立即生效

### 🛡️ 管理面板
- **系统监控**: 实时服务器状态和统计信息
- **用户管理**: 在线用户查看和禁言操作
- **房间管理**: 完整的房间创建、删除、统计功能
- **广播消息**: 向所有用户发送系统通知

## 🚀 快速开始

### 系统要求
- Node.js 16.0 或更高版本
- 现代浏览器（Chrome、Firefox、Edge等）
- 内网环境

### 安装部署

1. **克隆项目**
```bash
git clone https://github.com/ChasonWang2012/LanTalk.git
cd LanTalk
```

2. **安装依赖**
```bash
cd server
npm install
```

3. **启动服务器**
```bash
node server.js
```

4. **访问应用**
```
聊天室: http://你的服务器IP:3001/client/index.html
管理面板: http://你的服务器IP:3001/admin/admin.html
```

### 配置文件
服务器启动后会自动显示访问地址：
```
🚀 内网聊天室服务器已启动 v1.2.0
📍 本地访问: http://localhost:3001
🌐 内网访问: http://192.168.x.x:3001
💬 聊天室: http://192.168.x.x:3001/client/index.html
🛡️ 管理面板: http://192.168.x.x:3001/admin/admin.html
```

## 📁 项目结构

```
LanTalk/
├── server/                 # 服务器端代码
│   ├── server.js          # 主服务器文件
│   └── package.json       # 依赖配置
├── client/                 # 聊天客户端
│   └── index.html         # 聊天室界面
├── admin/                  # 管理面板
│   └── admin.html         # 管理界面
├── LICENSE                # MIT许可证
└── README.md              # 项目文档
```

## 🎯 使用指南

### 用户使用
1. 打开聊天室页面
2. 输入服务器IP地址和用户名
3. 加入默认聊天室或创建新房间
4. 开始聊天，支持Markdown语法

### 管理员使用
1. 打开管理面板页面
2. 监控系统状态和用户活动
3. 管理房间和用户权限
4. 发送系统广播消息

### Markdown 语法支持
```markdown
**粗体文本** *斜体文本* ~~删除线~~
`行内代码`

```代码块
function example() {
    return "Hello World";
}
```

# 标题1
## 标题2

> 引用文本

- 列表项1
- 列表项2

[链接文本](https://example.com)
```

## 🔧 API 接口

### 服务器状态
```http
GET /api/health
```

### 用户管理
```http
GET    /api/users
POST   /api/mute-ip
POST   /api/unmute-ip
GET    /api/muted-ips
```

### 房间管理
```http
GET    /api/rooms
POST   /api/rooms
DELETE /api/rooms/:roomId
POST   /api/rooms/:roomId/kick-users
```

### 系统广播
```http
POST /api/broadcast
```

## 🛡️ 安全特性

- **IP验证**: 基于IP地址的用户识别
- **内容消毒**: 所有用户输入经过安全处理
- **权限控制**: 严格的权限验证机制
- **操作确认**: 危险操作需要二次确认

## 📊 版本历史

### v1.2.0 (当前版本)
- ✅ 完整的房间管理系统
- ✅ 管理员强制操作支持
- ✅ 增强的权限控制
- ✅ 专业的管理面板

### v1.1.0
- ✅ Markdown消息支持
- ✅ 多房间聊天功能
- ✅ 基础管理面板

### v1.0.0
- ✅ 基础实时聊天
- ✅ 用户列表显示
- ✅ IP禁言功能

## 🤝 贡献指南

我们欢迎各种形式的贡献！

1. Fork 本项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🐛 问题反馈

如果你遇到任何问题或有改进建议，请通过以下方式反馈：

- [GitHub Issues](https://github.com/ChasonWang2012/LanTalk/issues)
- 项目讨论区
- 直接联系维护者

## 🙏 致谢

感谢所有为项目做出贡献的开发者！
特别感谢AI助手在开发过程中的技术支持。

---

**⭐ 如果这个项目对你有帮助，请给我们一个star！**

*让内网沟通更简单、更安全、更高效* 🚀